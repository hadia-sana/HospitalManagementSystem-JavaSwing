/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms;

/**
 *
 * @author Hp
 */
public class beds {
    int bednumb ;int wardnumb;int patient_id ;String status;

    public beds(int bednumb, int wardnumb, int patient_id, String status) {
        this.bednumb = bednumb;
        this.wardnumb = wardnumb;
        this.patient_id = patient_id;
        this.status = status;
    }

    public beds(int bednumb, int wardnumb) {
        this.bednumb = bednumb;
        this.wardnumb = wardnumb;
    }

    public beds() {
    }

    public int getBednumb() {
        return bednumb;
    }

    public void setBednumb(int bednumb) {
        this.bednumb = bednumb;
    }

    public int getWardnumb() {
        return wardnumb;
    }

    public void setWardnumb(int wardnumb) {
        this.wardnumb = wardnumb;
    }

    public int getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(int patient_id) {
        this.patient_id = patient_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
