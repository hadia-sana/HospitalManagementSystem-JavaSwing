package hms;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Hp
 */
public class doctor {
   
    private String name;
    private int age;
    private String gender;
    private int salary;
    private String qualification;

    public doctor(String name, int age, String gender, int salary, String qualification) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.salary = salary;
        this.qualification = qualification;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public int getSalary() {
        return salary;
    }

    public String getQualification() {
        return qualification;
    }

    

    
    
}
