 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms;

/**
 *
 * @author Hp
 */
public class shifts {
    String docname;
    String nurse1name;
    String nurse2name;
    int wardnumb;
    String shifttiming;

    public shifts() {
    }

    public String getDocname() {
        return docname;
    }

    public void setDocname(String docname) {
        this.docname = docname;
    }

    public String getNurse1name() {
        return nurse1name;
    }

    public void setNurse1name(String nurse1name) {
        this.nurse1name = nurse1name;
    }

    public String getNurse2name() {
        return nurse2name;
    }

    public void setNurse2name(String nurse2name) {
        this.nurse2name = nurse2name;
    }

    public int getWardnumb() {
        return wardnumb;
    }

    public void setWardnumb(int wardnumb) {
        this.wardnumb = wardnumb;
    }

    public String getShifttiming() {
        return shifttiming;
    }

    public void setShifttiming(String shifttiming) {
        this.shifttiming = shifttiming;
    }

    public shifts(String docname, String nurse1name, String nurse2name, int wardnumb, String shifttiming) {
        this.docname = docname;
        this.nurse1name = nurse1name;
        this.nurse2name = nurse2name;
        this.wardnumb = wardnumb;
        this.shifttiming = shifttiming;
    }
    
}
