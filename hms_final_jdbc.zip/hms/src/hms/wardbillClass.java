/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms;

import java.time.LocalDate;

/**
 *
 * @author Hp
 */
public class wardbillClass {
    String patientname ;int appointmentid ;float amount;LocalDate datt ;String wardname ;int days ;float perdayamount ;

    public wardbillClass(String patientname, int appointmentid, LocalDate datt, String wardname, int days, float perdayamount) {
        this.patientname = patientname;
        this.appointmentid = appointmentid;
        this.datt = datt;
        this.wardname = wardname;
        this.days = days;
        this.perdayamount = perdayamount;
    }

    public String getPatientname() {
        return patientname;
    }

    public void setPatientname(String patientname) {
        this.patientname = patientname;
    }

    public int getAppointmentid() {
        return appointmentid;
    }

    public void setAppointmentid(int appointmentid) {
        this.appointmentid = appointmentid;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public LocalDate getDatt() {
        return datt;
    }

    public void setDatt(LocalDate datt) {
        this.datt = datt;
    }

    public String getWardname() {
        return wardname;
    }

    public void setWardname(String wardname) {
        this.wardname = wardname;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public float getPerdayamount() {
        return perdayamount;
    }

    public void setPerdayamount(float perdayamount) {
        this.perdayamount = perdayamount;
    }
    
}
