/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms;

import java.time.LocalDate;

/**
 *
 * @author Hp
 */
public class recommend {
    String docname;
    String patientname;
    String collabedhosp;
    String recommend_special;
    String reason;
    LocalDate date;

    public recommend() {
    }

    public recommend(String docname, String patientname, String collabedhosp, String recommend_special,String reason, LocalDate date) {
        this.docname = docname;
        this.patientname = patientname;
        this.collabedhosp = collabedhosp;
        this.recommend_special = recommend_special;
        this.reason=reason;
        this.date = date;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getDocname() {
        return docname;
    }

    public void setDocname(String docname) {
        this.docname = docname;
    }

    public String getPatientname() {
        return patientname;
    }

    public void setPatientname(String patientname) {
        this.patientname = patientname;
    }

    public String getCollabedhosp() {
        return collabedhosp;
    }

    public void setCollabedhosp(String collabedhosp) {
        this.collabedhosp = collabedhosp;
    }

    public String getRecommend_special() {
        return recommend_special;
    }

    public void setRecommend_special(String recommend_special) {
        this.recommend_special = recommend_special;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
    
    
    
}
