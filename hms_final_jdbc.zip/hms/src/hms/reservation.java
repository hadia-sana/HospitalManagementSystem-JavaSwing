/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms;

/**
 *
 * @author Hp
 */
public class reservation {
    
int bednumb;int wardnumb;

    public int getBednumb() {
        return bednumb;
    }

    public void setBednumb(int bednumb) {
        this.bednumb = bednumb;
    }

    public int getWardnumb() {
        return wardnumb;
    }

    public void setWardnumb(int wardnumb) {
        this.wardnumb = wardnumb;
    }

    public reservation(int bednumb, int wardnumb) {
        this.bednumb = bednumb;
        this.wardnumb = wardnumb;
    }
}
