package hms;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Hp
 */
public class dto_implement implements dto_interface {
    public  void insertintopatient(patient obj){
    Connection conn= Hms.getconnection();
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
            CallableStatement st=conn.prepareCall("{Call addintopatient2(?,?,?,?,?)}");
            st.setInt(1,obj.getDocid());
            st.setString(2, obj.getName());
            st.setInt(3,obj.getAge());
            st.setString(4, obj.getGender());
            st.setString(5, obj.getDiagnose());
            
            st.executeUpdate();
             JOptionPane.showMessageDialog(null,"added");
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
         JOptionPane.showMessageDialog(null,"not found");}
    }
    @Override
    public  void insertintonurse(nurse obj){
    Connection conn= Hms.getconnection();
    CallableStatement st=null;
    // int id=-1;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call addnurse(?,?,?,?,?,?)}");
             st.setInt(1,obj.getId());
            st.setString(2, obj.getName());
            st.setInt(3,obj.getAge());
            st.setString(4, obj.getGender());
            st.setInt(5, obj.getSalary());
            st.setString(6,obj.getQualification());
            
            st.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
        
            
        
    }
    public  int insertintodoctor(doctor obj){
    Connection conn= Hms.getconnection();
    CallableStatement st=null;
    int id=-1;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call adddoctor3(?,?,?,?,?,?)}");
            st.setString(1, obj.getName());
            st.setInt(2,obj.getAge());
            st.setString(3, obj.getGender());
            st.setInt(4, obj.getSalary());
            st.setString(5,obj.getQualification());
            st.registerOutParameter(6,java.sql.Types.OTHER);
            st.executeUpdate();
            id=st.getInt(6);
            JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
        
            return id;
        
    }
    public void deletedoctor(String name){
        Connection conn=Hms.getconnection();
        
    PreparedStatement st=null;
        try {
            st = conn.prepareStatement("delete from doctor where name = ? ");
        st.setString(1,name);
    st.executeUpdate();
    JOptionPane.showMessageDialog(null,"deleted");
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
    }
    public void deletepatient(String name){
        Connection conn=Hms.getconnection();
        
    PreparedStatement st;
        try {
            st = conn.prepareStatement("delete from patient2 where name = ? ");
        st.setString(1,name);
    st.executeUpdate();
    JOptionPane.showMessageDialog(null,"deleted");
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
    }
   
    /*public void sarchpatient(String name){
     Connection conn=Hms.getconnection();
     PreparedStatement st=null;
        try {
            st = conn.prepareStatement("select * from patient2 where name = ? ");
        st.setString(1,name);
        try{
        ResultSet rs=st.executeQuery();
        DefaultTableModel model=(DefaultTableModel) jTable1.getmodel();
        while(rs.next()){
        
        }
        
        }
        catch(Exception e){
        JOptionPane.showMessageDialog(null,"not found");
        }
    
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    }*/
    public void sarchdoctor(String name){
     Connection conn=Hms.getconnection();
     PreparedStatement st=null;
        try {
            st = conn.prepareStatement("select * from doctor where name = ? ");
        st.setString(1,name);
        try{
        ResultSet rs=st.executeQuery();}
        catch(Exception e){
        JOptionPane.showMessageDialog(null,"not found");
        }
    
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    }
    public void addappointment(appointment obj){
    Connection conn=Hms.getconnection();
        try {
            CallableStatement st=conn.prepareCall("{call addappoint(?,?,?,?,?)}");
            //(newdatt,newtim,newdocid,newpid,apptype2);

            st.setDate(1,java.sql.Date.valueOf(obj.getDate()));
             st.setTime(2,java.sql.Time.valueOf (obj.getTime()));
             st.setInt(3,obj.getDocid());
             st.setInt(4,obj.getPid());
             st.setString(5,obj.getType());
             st.executeUpdate();
             JOptionPane.showMessageDialog(null,"added");
        
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");
        }
    
    
    
    }
    public void datewisebill(LocalDate date){
    
    
    }
    public void addbill(bill obj){Connection conn=Hms.getconnection();
        try {
            CallableStatement st=conn.prepareCall("{call addbill(?,?,?,?)}");
            //(newdatt,newtim,newdocid,newpid,apptype2);

            st.setDate(1,java.sql.Date.valueOf(obj.getDate()));
          
             st.setInt(2,obj.getPayamount());
             
             st.setString(3,obj.getName());
             st.setInt(4,obj.getAppid());
             st.executeUpdate();
             JOptionPane.showMessageDialog(null,"added");
        
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");
        }
    
    }

    @Override
    public void addrecommendation(recommend obj) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
     Connection conn= Hms.getconnection();
    CallableStatement st=null;
    // int id=-1;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call addrecommendation(?,?,?,?,?,?)}");
             
            st.setString(1, obj.getDocname());
             st.setString(2, obj.getPatientname());
              st.setString(3, obj.getCollabedhosp());
               st.setString(4, obj.getRecommend_special());
                st.setString(5, obj.getReason());
                st.setDate(6,java.sql.Date.valueOf(obj.getDate()));
                
            
            
            st.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
    }

    @Override
    public void addward(ward obj) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    Connection conn= Hms.getconnection();
    CallableStatement st=null;
    
    // int id=-1;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call addward(?,?,?,?)}");
             
            st.setInt(1, obj.getNumb());
             st.setString(2, obj.getType());
              st.setInt(3, obj.getNoofbeds());
               st.setInt(4, obj.getFloor());
                st.executeUpdate();
                CallableStatement st2=null;
                for(int i=1;i<=obj.getNoofbeds();i++){
               try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st2=conn.prepareCall("{Call addbeds(?,?)}");
             
            st2.setInt(1, i);
            st2.setInt(2, obj.getNumb());
             
              
                
                
            
            
            st2.executeUpdate();
            
            //JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found bed in ward");}
    
                }
            
            
            
            
            JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
    }

    @Override
    public void addshift(shifts obj) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
     Connection conn= Hms.getconnection();
    CallableStatement st=null;
    // int id=-1;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call addshift(?,?,?,?,?)}");
             st.setString(1, obj.getDocname());
             st.setString(2, obj.getNurse1name());
             st.setString(3, obj.getNurse2name());
            st.setInt(4, obj.getWardnumb());
             st.setString(5, obj.getShifttiming());
              
                
                
            
            
            st.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
    
    }

    public void addbed(beds obj) {
         Connection conn= Hms.getconnection();
    CallableStatement st=null;
    // int id=-1;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call addbeds(?,?)}");
             
            st.setInt(1, obj.getBednumb());
            st.setInt(2, obj.getWardnumb());
             
              
                
                
            
            
            st.executeUpdate();
            
            //JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     public void addreservation(reservation obj) {
         Connection conn= Hms.getconnection();
    CallableStatement st=null;
    // int id=-1;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call addreservation(?,?)}");
             
            st.setInt(1, obj.getBednumb());
            st.setInt(2, obj.getWardnumb());
             
      
            st.executeUpdate();
            
            //JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public void reservebed(beds obj) {
         Connection conn= Hms.getconnection();
    CallableStatement st=null;
    // int id=-1;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call reservebeds(?,?,?,?)}");
             
            st.setInt(1, obj.getBednumb());
            st.setInt(2, obj.getWardnumb());
            st.setInt(3, obj.getPatient_id());
            st.setString(4, "reserved");
             
              
                
                
            
            
            st.executeUpdate();
            
            //JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public float addwardbill(wardbillClass obj) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    Connection conn= Hms.getconnection();
    CallableStatement st=null;
    float amount=0.0f;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call wardbill2(?,?,?,?,?,?)}");
            st.setString(1, obj.getPatientname());
            st.setInt(2,obj.getAppointmentid());
            st.setDate(3, java.sql.Date.valueOf(obj.getDatt()));
            
            st.setString(4,obj.getWardname());
            st.setInt(5, obj.getDays());
            st.setFloat(6, obj.getPerdayamount());
            st.executeUpdate();
            st=conn.prepareCall("{Call getamount2(?,?)}");
            st.setInt(1,obj.getAppointmentid());
            st.registerOutParameter(2,java.sql.Types.FLOAT);
            st.execute();
            amount=st.getFloat(2);
            //JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"imp not found"+ex.getMessage());}
        
            return amount;
        
    
    
    }

    
}
