/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms;

/**
 *
 * @author Hp
 */
public class ward {
    int numb;String type;int noofbeds;

    public int getNumb() {
        return numb;
    }

    public void setNumb(int numb) {
        this.numb = numb;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getNoofbeds() {
        return noofbeds;
    }

    public void setNoofbeds(int noofbeds) {
        this.noofbeds = noofbeds;
    }

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public ward(int numb, String type, int noofbeds, int floor) {
        this.numb = numb;
        this.type = type;
        this.noofbeds = noofbeds;
        this.floor = floor;
    }
int floor;
}
